Hi Guy!
Lưu ý sử dụng:
Trong vscode, nhớ tải tải extensions: Live sever để chạy code.
Push code nhớ ghi code thêm những gì.

Để chạy được product pages, Cần pull code về sau đó vào git bash gõ: npm run start-API để khởi động fake API sau đó trang product mới hiển thị sản phẩm

api:
https://hostapi-g350.onrender.com/api/product
https://hostapi-g350.onrender.com/api/cartUser
Một số website tham khảo UI:
https://tarmor.vn/
https://motstore.vn/
https://bitis.com.vn/
https://myshoes.vn/

